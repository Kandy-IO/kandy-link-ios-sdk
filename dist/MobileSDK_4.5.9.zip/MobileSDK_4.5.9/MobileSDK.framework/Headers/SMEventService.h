/*
 * Copyright © 2014 GENBAND. All Rights Reserved.
 *
 * GENBAND CONFIDENTIAL. All information, copyrights, trade secrets
 * and other intellectual property rights, contained herein are the property
 * of GENBAND. This document is strictly confidential and must not be
 * copied, accessed, disclosed or used in any manner, in whole or in part,
 * without GENBAND's express written authorization.
 *
 * @version: 4.5.9
 *
 */

#import <Foundation/Foundation.h>
@class SMMobileError;

/**
 * Event Service enables event injection to MobileSDK from Application layer
 *
 * @since 3.0.5
 **/
@interface SMEventService : NSObject


/**
 * Enables message passing to MobileSDK (messages can be sent via push notification, websocket or any different way)
 *
 * @param message json formatted string for incoming notification
 * @param error json object parse error if exists
 *
 * @since 3.0.5
 * @updated 4.4.1
 */
- (void) receiveNotification:(NSString*)message withError:(SMMobileError **)error;

/**
 * Constructing is disallowed from API level.
 */
- (id)init __attribute__((unavailable("init is not a supported initializer for this class.")));

@end
