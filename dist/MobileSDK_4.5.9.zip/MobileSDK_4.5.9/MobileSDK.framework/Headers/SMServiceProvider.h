/*
 * Copyright © 2014 GENBAND. All Rights Reserved.
 *
 * GENBAND CONFIDENTIAL. All information, copyrights, trade secrets
 * and other intellectual property rights, contained herein are the property
 * of GENBAND. This document is strictly confidential and must not be
 * copied, accessed, disclosed or used in any manner, in whole or in part,
 * without GENBAND's express written authorization.
 *
 * @version: 4.5.9
 *
 */


#import <Foundation/Foundation.h>


@class SMEventService;
@class SMRegistrationService;

@protocol SMCallServiceDelegate;
@protocol SMAddressBookServiceDelegate;
@protocol SMPresenceServiceDelegate;
@protocol SMIMServiceDelegate;
@protocol SMCallLogServiceDelegate;

NS_ASSUME_NONNULL_BEGIN

/**
 * @brief This class is needed for calling the services.
 * @since 2.0.0
 */
@interface SMServiceProvider : NSObject

/**
 * This method returns an instance of ServiceProvider using Singleton Pattern
 * @return ServiceProvider
 * @since 2.0.0
 */
+ (SMServiceProvider *) getInstance;


/**
 * This method returns (creates if necessary) an instance of AddressBookService using Singleton Pattern
 * @return AddressBookServiceDelegate
 * @since 2.0.0
 */
- (id<SMAddressBookServiceDelegate>) getAddressBookService;


/**
 * This method returns (creates if necessary) an instance of PresenceService using Singleton Pattern
 * @return PresenceServiceDelegate
 * @since 2.0.0
 */
- (id<SMPresenceServiceDelegate>) getPresenceService;


/**
 * This method returns (creates if necessary) an instance of RegistrationService using Singleton Pattern
 * @return RegistrationServiceDelegate
 * @since 2.0.0
 */
- (SMRegistrationService *) getRegistrationService;


/**
 * This method returns (creates if necessary) an instance of CallService using Singleton Pattern
 * @return CallServiceDelegate
 * @since 2.0.0
 */
- (id<SMCallServiceDelegate>) getCallService;


/**
 * This method returns (creates if necessary) an instance of CallLogService using Singleton Pattern
 * @return CallLogServiceDelegate
 * @since 2.0.0
 */
- (id<SMCallLogServiceDelegate>) getCallLogService;


/**
 * This method returns (creates if necessary) an instance of IMService using Singleton Pattern
 * @return IMServiceDelegate
 * @since 2.0.0
 */
- (id<SMIMServiceDelegate>) getIMService;


/**
 * This method returns (creates if necessary) an instance of Event using Singleton Pattern
 * @return EventService
 * @since 3.0.5
 */
- (SMEventService *) getEventService;


/**
 * This method returns the version information about the SDK 
 * @return NSString
 * @since 2.0.0
 */
- (NSString *) getVersion;

NS_ASSUME_NONNULL_END

@end
